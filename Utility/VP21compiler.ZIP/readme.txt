1. copy VP21 from zip file to C root directory
2. add C:\VP21\BIN.W32 to path variable
3. go to your "borg" directory, run cmd from there and type vp
4. from vp menu open borg.pas and "build", compiled exe is in C:\VP21\OUT.W32 dir
