1. copy VP21 to C root directory
2. add C:\VP21\BIN.W32 to path variable
3. go to your "borg" directory run cmd from there and type vp
4. from vp gmenu open borg.pas and "nuild", compiled exe is in C:\VP21\OUT.W32 dir
